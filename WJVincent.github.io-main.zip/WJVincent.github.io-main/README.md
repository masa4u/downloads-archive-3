# William Vincent

### Husband, Father, Friend, and Passionate Software Developer.

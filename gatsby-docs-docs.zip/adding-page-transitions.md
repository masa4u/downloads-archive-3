---
title: Adding Page Transitions
---

Page transitions give users a better experience when navigating between pages. There are a number of ways to add them to your Gatsby site.

<GuideList slug={props.slug} />

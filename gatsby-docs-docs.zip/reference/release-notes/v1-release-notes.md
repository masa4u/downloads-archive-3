---
title: v1 Release Notes
---

Check out the following useful links for Gatsby version 1:

- [v1 documentation](https://v1.gatsbyjs.org/)
- [v1 changelog](https://github.com/gatsbyjs/gatsby/blob/master/packages/gatsby/CHANGELOG.md#100---2017-07-06)
- [v1 release announcement](/blog/gatsby-v1/)

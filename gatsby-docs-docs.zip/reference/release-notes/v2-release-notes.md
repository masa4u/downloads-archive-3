---
title: v2 Release Notes
---

Check out the following useful links for Gatsby v2:

- [v2 release announcement](/blog/2018-09-17-gatsby-v2/)
- [Migrating from v1 to v2](/docs/reference/release-notes/migrating-from-v1-to-v2/)
- [v2 documentation](/docs/)
- [v2 changelog](https://github.com/gatsbyjs/gatsby/blob/master/packages/gatsby/CHANGELOG.md#200-2018-09-17)

---
title: Querying with Sift
---

This article is deprecated in favor of [query-filters](/docs/query-filters).

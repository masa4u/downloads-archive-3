---
title: Glamor
---

CSS-in-JS library [Glamor](https://github.com/threepointone/glamor) is not actively maintained. The maintainer recommends using [Emotion](/docs/how-to/styling/emotion/).

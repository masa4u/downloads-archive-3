---
title: Gatsby for Freelancers
issue: https://github.com/gatsbyjs/gatsby/issues/21069
---

As a freelancer, the most important thing is [helping clients understand](/docs/using-gatsby-professionally/winning-over-clients/) the benefits of Gatsby.

--

This is a stub. Help our community expand it.

Please use the [Gatsby Style Guide](/contributing/gatsby-style-guide/) to ensure your
pull request gets accepted.

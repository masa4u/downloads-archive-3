
# TODO

- [ ] distinct github projects
    - [ ] show time since last commit
    - [ ] show if it's archived
- [ ] check for valid urls
- [ ] review classification
- [ ] submit to awesome lists project


# ISSUES

- Some repos have their own URL. How to deal with that?
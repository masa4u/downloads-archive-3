quants

https://sites.google.com/site/peterreinhardhansen/

http://www.dixiederivatives.com/excelpricingfiles.htm
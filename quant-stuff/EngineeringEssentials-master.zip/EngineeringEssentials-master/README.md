# Pull Requests

There is no contribution agreement in place, so we are not accepting external pull requests at this time.

# Engineering Essentials

Goldman Sachs Engineering Essentials is a four day program designed to help current college sophomores develop the essential skills and tools to prepare for a successful career as a software engineer.

Read more at http://www.goldmansachs.com/careers/students/programs/americas/engineering-essentials.html

## Technical Curriculum

As part of the technical curriculum, you will learn how to model a system, build RESTful services and create a user interface for your application.

## Case Study - Stock Visualization Application

Apply the knowledge that you have learned from the modelling, services and UI learning sessions to build a stock visualization application

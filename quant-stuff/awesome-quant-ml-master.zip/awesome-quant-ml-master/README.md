# awesome-quant-ml

## Books

- Inside the black box
- Advances in financial machine learning

## Websites

- [Marcos López de Prado website](http://www.quantresearch.org/)

### Crowd-sourcing

- [Quantopian](https://www.quantopian.com/)
- [WorldQuant](https://www.worldquant.com/home/)
- [Alpha Trading Labs](https://www.alphatradinglabs.com/)
- [Numerai](https://numer.ai/)

### Data

- [AlternativeData.org](https://alternativedata.org/) - Source of alternative data.
- [Quandl](https://www.quandl.com/) - Financial, economic, and alternative datasets.
